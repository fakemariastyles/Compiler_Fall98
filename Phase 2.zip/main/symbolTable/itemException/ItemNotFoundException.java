package main.symbolTable.itemException;

import main.compileError.CompileErrorException;

public class ItemNotFoundException extends CompileErrorException {
}
