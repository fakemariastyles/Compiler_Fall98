package main.ast.node.statement;

import main.ast.node.Node;

public abstract class Statement extends Node {

}
