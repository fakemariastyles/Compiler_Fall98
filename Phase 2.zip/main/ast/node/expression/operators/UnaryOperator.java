package main.ast.node.expression.operators;

public enum UnaryOperator {
    not, minus, preinc, postinc, predec, postdec
}