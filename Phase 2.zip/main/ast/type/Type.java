package main.ast.type;

import main.ast.node.Node;

public abstract class Type extends Node {
    public abstract String toString();
}
