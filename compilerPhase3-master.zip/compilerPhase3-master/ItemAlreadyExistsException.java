public class ItemAlreadyExistsException extends Exception {
}